import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class handlingMultipleWindow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new FirefoxDriver();
		driver.get("http://gmail.com");
		driver.findElements(By.id(""));
		Set<String> ids = driver.getWindowHandles();
		Iterator <String> it = ids.iterator();
		String parent = it.next(); // gets parent id
		String child = it.next();// gets child id
		driver.switchTo().window(child);
		System.out.println(driver.getTitle());
	}

}
