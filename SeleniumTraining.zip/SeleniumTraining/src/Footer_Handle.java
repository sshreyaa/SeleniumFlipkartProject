import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Footer_Handle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();
		driver.get("http://qaclickacademy.com/practice.php");
		System.out.println(driver.findElements(By.tagName("a")).size());// this will get the size of the links count in a page
		WebElement footerdriver = driver.findElement(By.id("gf-BIG"));// limiting webdriver scope to footer only

		System.out.println(footerdriver.findElements(By.tagName("a")).size());// this will get the size of the links count in the footer

		//hitting the 1st coloumn
		WebElement  coloumndriver = footerdriver.findElement(By.xpath(""));
		System.out.println(coloumndriver.findElements(By.tagName("a")).size());

		//clicking on each link to check if it opens to a new page
		for(int i =0 ; i<coloumndriver.findElements(By.tagName("a")).size(); i++)
		{
			String clickOnLink = Keys.chord(Keys.CONTROL,Keys.ENTER); //ctrl+Click to open on new tab
			coloumndriver.findElement(By.tagName("a")).click();
		}

		//open all tabs and gets the title
		Set<String> windowHandle = driver.getWindowHandles();
		Iterator<String> it = windowHandle.iterator();

		while(it.hasNext())
		{ 
			driver.switchTo().window(it.next());
			System.out.println(driver.getTitle());

		}


	}

}
