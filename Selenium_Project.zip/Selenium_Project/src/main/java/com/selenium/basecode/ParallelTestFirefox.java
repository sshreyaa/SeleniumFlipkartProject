package com.selenium.basecode;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.swing.JSlider;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;


import com.selenium.multiplebrowser.MultipleBrowser;



public class ParallelTestFirefox extends MultipleBrowser{
	public static Properties prop;

	@Test
	public  void executeTest() {

		//Product to search
		String searchProduct = "Bluetooth Headphones";
		//Launching Browser
		driver.get("https://www.flipkart.com/");
		


		//Maximizing the window
		driver.manage().window().maximize();
		//Closing the login screen
		driver.findElement(By.xpath("//button[@class=\"_2AkmmA _29YdH8\"]")).click();


		//Check Search Box is Displayed
		WebElement searchBox = driver.findElement(By.name("q"));

		//Enter TV in Search text box
		searchBox.sendKeys(searchProduct);

		//Clicked on Search button
		driver.findElement(By.xpath("//button[@class='vh79eN']")).click();

		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		//filter for popularity

		driver.findElement(By.xpath("//div[text()='Popularity']")).click();

		try {
			//setting price range between 500 to 1500
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			WebElement sliderOne = driver.findElement(By.xpath("//div[@class='_3G9WVX oVjMho']//div[@class='_3aQU3C']"));
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			WebElement sliderTwo= driver.findElement(By.xpath("//div[@class='_3G9WVX _2N3EuE']//div[@class='_3aQU3C']"));
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			Actions act = new Actions(driver);
			act.dragAndDropBy(sliderOne, 33, 0).release().build().perform();
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			act.dragAndDropBy(sliderTwo, -66, 0).release().build().perform();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

			//Get product list
			List<WebElement> productList = driver.findElements(By.xpath("//a[@class='_2cLu-l']"));
			List<WebElement> productPriceList = driver.findElements(By.xpath("//div[@class='_1vC4OE']"));

			//Use of HashMaop to store Products and Their prices(after conversion to Integer)
			String productName;
			String productPrice;
			int productIntegerPrice;



			HashMap<Integer, String> map_final_products = new HashMap<Integer,String>();
			for(int i=0;i<productList.size() && i<5 ;i++) {
				productName = productList.get(i).getText();//Iterate and fetch product name
				productPrice = productPriceList.get(i).getText();//Iterate and fetch product price
				productPrice = productPrice.replaceAll("[^0-9]", "");//Replace anything will space other than numbers
				productIntegerPrice = Integer.parseInt(productPrice);//Convert to Integer

				System.out.println(productName); 
				System.out.println(productIntegerPrice); 
			}


			System.out.println(driver.getTitle());

		}
		catch (StaleElementReferenceException e)
		{System.out.println(e);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		}



	}

}
